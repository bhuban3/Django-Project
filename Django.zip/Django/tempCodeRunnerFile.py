from mysqlconnect import mysql_connect

db = mysql_connect()
db.connect_db()
output = db.execute_query("SHOW DATABASES;")
print("Available Databases:")
for db_name in output:
    print("-", db_name[0])
db.close_connection()