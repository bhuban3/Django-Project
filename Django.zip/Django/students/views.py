from django.shortcuts import render, redirect, get_object_or_404
from .models import Student
from .forms import StudentForm

# Create
def create_student(request):
    form = StudentForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('list_students')
    return render(request, 'students/student_form.html', {'form': form})

# Read
def list_students(request):
    students = Student.objects.all()
    return render(request, 'students/student_list.html', {'students': students})

# Update
def update_student(request, pk):
    student = get_object_or_404(Student, pk=pk)
    form = StudentForm(request.POST or None, instance=student)
    if form.is_valid():
        form.save()
        return redirect('list_students')
    return render(request, 'students/student_form.html', {'form': form})

# Delete
def delete_student(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == 'POST':
        student.delete()
        return redirect('list_students')
    return render(request, 'students/confirm_delete.html', {'student': student})
